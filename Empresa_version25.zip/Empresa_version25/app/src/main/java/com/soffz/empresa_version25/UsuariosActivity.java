package com.soffz.empresa_version25;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UsuariosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usuarios);
    }
}